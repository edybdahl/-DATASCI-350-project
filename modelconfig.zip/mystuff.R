##--------------------------------------------
##
## Indevidual Project
##
## Class: PCE Data Science Methods Class
##
## Creator: Eric Dybdahl
##
##--------------------------------------------

library(sp,rgdal)
library(maptools)
library(data.table)
library(rgdal)
library(sp)
require(logging)
library("Imap")
library(caret)
library(ROCR)

output_file_name = "Data Report Output"

# Declare the loading data function
load_data = function(datafile, logger=NA){
  data = read.csv(datafile, stringsAsFactors = FALSE)
  loginfo(sprintf("Loaded Data %s",datafile), logger="data_logger")
  
  # Check if any data was loaded
  if(nrow(data)==0){
    logwarn("No Data Loaded", logger="data_logger")
  }
  return(data)
}

#create onefuction for these.
#seperate camma separated items
split_cat = function(x){
   return(unlist(strsplit(x, ",[ ]*", perl=TRUE)) )
}

#seperate brackets separated items
split_catb = function(x){
  y = gsub('{', '', x , perl=TRUE)
  return(unlist(strsplit(y, "}[ ]*", perl=TRUE)) )
}

#seperate brackets separated items
split_catbc = function(x){
  y = gsub('\"', '', x , perl=TRUE)
  return(unlist(strsplit(y, ",[ ]*", perl=TRUE)) )
}

# get the sum of x in vector y
produce_binary = function(x,y){
  return(sum(grepl(x,y, perl=TRUE)))
}

# get the existance of x in vector y
produce_binary_list = function(x,y){
  return(grepl(x,y, perl=TRUE))
}

# get the fraction that is not unique
unique_dif = function(x){
  return((length(x) - length(unique(x)))/length(x))
}

# get the unique list of items in liwt of comma deliminated items and return it
# as a data frame.
get_list = function(x)
{
  lst = lapply(unique(x),FUN=split_cat)
  all_stuff = sort(unique(unlist(lst))) 
  all_stuff = as.data.frame(all_stuff)
  
  return(all_stuff)
}

# get the feqency of each item in a list and return as a data frame
get_sums = function(x)
{
  all_stuff = get_list(x)
  
  all_stuff$sum = apply(all_stuff, 1, FUN=produce_binary, x )
  return(all_stuff)
}

# Produces a full data frame of binary column vectors of of existance in list
# x of items in list y
get_existence_with_list = function(x,y)
{ 
  out = apply(y, 1, FUN=produce_binary_list, x )
  out = as.data.frame(out)
  names(out) = unlist(y)
  return(out)
}

# Produces a data frame of binary columns of x items exitance in list x
get_existance = function(x)
{
  all_stuff = get_list(x)
  
  out = apply(all_stuff, 1, FUN=produce_binary_list, x )
  out = as.data.frame(out)
  names(out) = unlist(all_stuff)
  return(out)
}
  
# function to for apply to concatinate
mycat = function(x){
  return(x)
}

# get rows or sites where y exists in the primary commodity list
get_rows_exist = function(x,y)
{
  return(which(produce_binary_list(y,x$commod1)))
}

# well, the same thing as get_exsisence.for a defoned column y in
# data frame x
create_model_frame = function(x,y)
{
  model_frame = get_existance(x[,y])  
  return(model_frame)
}

# using column z gets existance from data frame x using list from data frame y
create_model_frame_list = function(x,y,z)
{
  model_frame = get_existence_with_list(x[,z],get_list(y[,z]))  
  return(model_frame)
}

# Gets the dep_it of the closet site in x to y
get_close_index = function(x,y){
  
#gdist Geodesic distance (great circle distance) between points
Dist <- gdist(lat.1=y$latitude,
              lon.1=y$longitude,
              lat.2=x$LATITUDE,
              lon.2=x$LONGITUDE)

#Output the shortest distance - Min
return(c(y[which.min(Dist),]$dep_id,min(Dist)))
}

loading_data = function(){
  file_name = 'mrds.csv'
  mrds <- load_data(file_name)
  
  #dep_id - A unique 12-digit system generated sequence number which references records of information pertaining to a mineral property 
  #mrds_id - Identification number used to refer to this entry in the Mineral Resources Data System, if the record appeared in that database. 
  #mas_id - Identification number for this site as it appeared in the Mineral Availability System/Mineral Industry Locator System database, 
  #site_name - Current (preferred) form of the name of the site, deposit, or operation to which the record refers. 
  #prev_name -  Names by which the site or operation has bee known in the past. 
  #latitude - Geographic latitude of the site, WGS84 
  #longitude - Geographic longitude of the site, WGS84 
  #region Code - indicating the geographic region 
  #country - Name of the country in which the site is located 
  #state- Name of the state or province in which the site is located 
  #county -  Name of the county in which the site is located 
  #com_type Type of commodities present: metallic (M), non-metallic (N), or both (B) 
  #commod1 - Primary commodities present, a comma-separated list. Commodity qualifiers follow each commodity, delimited by a hyphen. 
  #commod2 - Secondary commodities present, a comma-separated list. Commodity qualifiers follow each commodity, delimited by a hyphen. 
  #commod3 - Other commodities present, a comma-separated list. Commodity qualifiers follow each commodity, delimited by a hyphen. 
  #oper_type - Type of operation existing or proposed at the site. 
  #dep_type - General type of deposit or resource present at the site. 
  #prod_size - A broad characterization of the magnitude of production at the site. 
  #dev_stat - Status of development of the resource or operation. 
  #ore - Name of the ore mineral or material found in this deposit. 
  #gangue - Name of the gangue mineral or material found in this deposit. 
  #other_matl - Name of other minerals or materials found in this deposit. 
  #orebody_fm - Form and shape of the ore body. 
  #work_type - General type of workings at the site. 
  #model - Mineral deposit models that characterize the site. Multiple models are delimited by braces, with a model number for each. 
  #alteration - Geochemical alteration, if any, believed to have been important in forming or modifying the ore materials of a deposit. 
  #conc_proc - Geological processes that are believed to have occurred to concentrate ore materials in the deposit 
  #ore_ctrl - Geologic features, typically structural, that exert control over the form, extent, or character of the deposit. 
  #reporter - Names of the persons primarily responsible for entering information about the site. 
  #hrock_unit - Lithologic and stratigraphic information regarding the host rocks for the ore deposit 
  #hrock_type -  Controlled term(s) indicating the type of host rocks, taken from Lithclass 6.2 
  #arock_unit - Lithologic and stratigraphic information regarding the rocks for the ore deposit that are not specifically identified as host ro 
  #arock_type - Controlled term(s) indicating the type of associated rocks, taken from Lithclass 6.2 
  #structure - Description of geological structures at or near the deposit. 
  #tectonic - Description of tectonic setting within which the deposit is found, includes regional geologic structure. 
  #ref - Bibliographic references providing information supporting the database record. Braces delimit multiple references. 
  #yfp_ba - Value < indicates production first began before the year specified in YR_FST_PRD; > indicates production began after that year. 
  #yr_fst_prd - Year of first production at the site. May be modified by YFP_BA. 
  #ylp_ba - Value < indicates production ended before the year specified in YR_LST_PRD; > indicates production ended after that year. 
  #yr_lst_prd - Year of last production at the site. May be modified by YLP_BA. 
  #dy_ba - If present, < in this field indicates that discovery occurred prior to the value in DISC_YR; likewise > indicates discovery occu 
  #disc_yr - Year the site was discovered. The value of DY_BA may modify the meaning of this value. 
  #prod_yrs - Description of the production history, including breaks or interruptions between first and last production years. 
  #discr - Name and address (if known) of the company, organization, or person most closely associated with the discovery of the resource. 
  
  mrds <- as.data.frame(mrds)
   
  file_name = 'mineplant.csv'
  inter_file_name = 'mineplantsave.csv'
  new_file_name = 'mineplantsaveas.csv'
  index_file_name = 'index.csv'
  
  mineplant = NULL
   
  if( new_file_name %in% list.files() ){
      mineplant = load_data(new_file_name)
  } else {
    start = 1
    if( inter_file_name %in% list.files() ){
       mineplant = load_data(inter_file_name)
       if (index_file_name %in% list.files()){
           start = as.int(load.data(index_file_name))
           if ( start > 1 ){
               start = start - 1
           }
       }
    } else {
       mineplant = load_data(file_name)
    }
    mrdsr = mrds[!is.na(mrds$latitude),]
    for (index in start:nrow(mineplant))
    {
       dist = get_close_index(mineplant[index,],mrdsr)
       mineplant$dep_id[index] = dist[1]
       mineplant$dist[index] = dist[2]
       write.table(index,file=index_file_name,row.names = FALSE)
       # find it way too show percentage done
       print((index/nrow(mineplant))*100)
       write.csv(mineplant, file=inter_file_name,row.names = FALSE)
       invisible(gc())
    }   
    write.csv(mineplant, file=new_file_name,row.names = FALSE)
  }
  
  #Put table description here after I clean it up
  #id - unique number
  #COMMODITY - the comodity of interest
  #SITE_NAME - name of the mine and\or plant
  #COMPANY_NA - name of the company that owns the mine and\or plant
  #STATE_LOCA - The state where the mine and\or plant is at
  #COUNTY - The county where the mine and\or plant is at
  #LATITUDE - the latitude of the mine and\or plant 
  #PLANT_MIN - M if mine P if plant and it can be both 
  #dep_id - unique identifier from the MRDS table calculated useing min distance 
  #         from latitude longitude data
  #dist - min distance between the two tables
  
  config_file_name = 'modelconfig.csv'
  testconfig <- load_data(config_file_name)
  
  return(list(mrds, mineplant, testconfig))
  
}

data_table_analysis = function(tables){
  
  mrds = as.data.frame(tables[1])
  mineplant = as.data.frame(tables[2])
  
  # removing na from location lattitudd and longitude
  mrds_good_location = mrds[!is.na(mrds$latitude),]
  
  # getting the plot of the hight frequency commodities 
  commodity = get_sums(mrds$commod1)
  commodity2 = get_sums(mrds$commod2)
  commodity3 = get_sums(mrds$commod3)
  
  commodity = merge(commodity, commodity2, by=c("all_stuff"), all.x=TRUE)  
  commodity = merge(commodity, commodity3, by=c("all_stuff"), all.x=TRUE)
  
  top_minerals = commodity[commodity$sum.x> 10000,]
  top_minerals = top_minerals[order(-top_minerals$sum.x),c("all_stuff","sum.x")]
  
  barplot( top_minerals$sum.x, density=seq(0, 100, length.out = 12))
  legend("topright",legend=top_minerals$all_stuff, box.lty=0, inset = -0.04,
         density = seq(0, 100, length.out = 12)) 
  
  # The sites ith year information
  years_there = mrds[!is.na(mrds$yr_fst_prd) | !is.na(mrds$yr_lst_prd),]
   
  # ceate pie charts of current commoditoes
  mp_commodity = aggregate(id ~ COMMODITY, data=mineplant , FUN=length) 
  
  wells = mp_commodity[mp_commodity$id > 113,]
  wells[nrow(wells) + 1,] = list("other", sum(mp_commodity[mp_commodity$id <= 113,]$id))
  wells = wells[order(-wells$id),]
  
  pie(wells$id, labels=wells$COMMODITY)
  
  wells = mp_commodity[mp_commodity$id <= 113 & mp_commodity$id > 18,]
  wells[nrow(wells) + 1,] = list("other", sum(mp_commodity[mp_commodity$id <= 18,]$id))
  wells = wells[order(-wells$id),]
  
  pie(wells$id, labels=wells$COMMODITY)
  
  # below this is commented out code used in investigation. keeping it around for
  # notes and reference.
  
  # determinijng id uniqueness
  #print(length(unique(mrds$dep_id)))
  #print(length(unique(mrds$mrds_id)))
  #print(length(unique(mrds$mas_id)))
  #print(length(unique(mrds$site_name)))
   
  # Region does not give you much there seems to be 
  # there is a lot of blank
  #print(length(unique(mrds$region)))
  #print(unique(mrds$region))
  #nrow(mrds[is.na(mrds$region) | mrds$region=="",])
  #nrow(mrds[mrds$region=="",])
  
  #rc = aggregate(dep_id~region, data=mrds, FUN=length)
  #sum(rc$dep_id)
  
  #The dominating country for information is United States
  #just might reduce the data down to look ar that sub group
  #I assume the data will be more complete.
  #print(length(unique(mrds$country)))
  #print(unique(mrds$country))
  
  #rco = aggregate(dep_id~country, data=mrds, FUN=length)
  #sum(rco$dep_id)
  
  #Sraight forward if US esle the definition changes, 
  #print(length(unique(mrds$state)))
  #print(unique(mrds$state))
  
  #The same here too
  #print(length(unique(mrds$county)))
  #print(unique(mrds$county))
  
  #Breakout by operation (mostly Unknown)
  #print(length(unique(mrds$oper_type)))
  #print(unique(mrds$oper_type))

  #rcd = aggregate(dep_id~oper_type, data=mrds, FUN=length)
  #sum(rcd$dep_id)
  
  # The values for this are L,M,N,S,U,Y 
  # Production size - Large, Medium, Small, Yes, No. 
  # From old MRDS, no guidelines were established for 
  # the size categories, which may have referred to the 
  # rate of production as opposed to the total cumulative production. 
  # U is probably unknown
  #print(length(unique(mrds$prod_size)))
  #print(unique(mrds$prod_size))
  
  #rcy = aggregate(dep_id~prod_size, data=mrds, FUN=length)
  #sum(rcy$dep_id)
  
  #rather messy but there might be catagories that I can seperate these into
  #maybe worth lookokg at
  #print(length(unique(mrds$dep_type)))
  #print(unique(mrds$dep_type))
  
  # big list descriptive
  #lst = lapply(unique(mrds$dep_type),FUN=split_cat)
  #unique(unlist(lst)) 
  
  #split between metal and non-metal with some having both.
  #print(length(unique(mrds$com_type)))
  #print(unique(mrds$com_type))
  
  #rct = aggregate(dep_id~com_type, data=mrds, FUN=length)
  #sum(rct$dep_id)
  
  #primary comodities messy and can be brocken out to other catigoties.
  #It looks like a tenth of the sites produced nothing primary
  #but others produced frm 1-8 items. There is also secondary and teriary.
  #not sure what consitutes the break. But for some sites the list of 
  #comodities can get very large
  #print(length(unique(mrds$commod1)))
  #print(unique(mrds$commod1))
  
  #rcc = aggregate(dep_id~commod1, data=mrds, FUN=length)
  #sum(rcc$dep_id)
  
  #print(length(unique(mrds$commod2)))
  #print(unique(mrds$commod2))
  
  #rch = aggregate(dep_id~commod2, data=mrds, FUN=length)
  #sum(rch$dep_id)
  
  #print(length(unique(mrds$commod3)))
  #print(unique(mrds$commod3))
  
  #rci = aggregate(dep_id~commod3, data=mrds, FUN=length)
  #sum(rci$dep_id)
  
  #us <- mrds[mrds$country == "United States",]
  #summary(us)
  
  #Some mines are accros state bounaries 
  #lst2 = lapply(unique(us$state),FUN=split_cat)
  #unique(unlist(lst2)) 
  
  # useful products
  #lst = lapply(unique(mrds$commod1),FUN=split_cat)
  #sort(unique(unlist(lst)))
  #lst = lapply(unique(mrds$commod2),FUN=split_cat)
  #unique(unlist(lst)) 
  #lst = lapply(unique(mrds$commod3),FUN=split_cat)
  #unique(unlist(lst)) 
  
  #raw stuff
  #lst = lapply(unique(mrds$ore),FUN=split_cat)
  #unique(unlist(lst)) 
  
  #raw_stuff = get_sums(mrds$ore)
  
  #lst = lapply(unique(mrds$gangue),FUN=split_cat)
  #unique(unlist(lst)) 
  
  #gangue_stuff = get_sums(mrds$gangue)
  
  #lst = lapply(unique(mrds$other_matl),FUN=split_cat)
  #unique(unlist(lst)) 
  
  #descriptiive messy
  #lst = lapply(unique(mrds$orebody_fm),FUN=split_cat)
  #unique(unlist(lst)) 
  
  #5 values somewhat like oper_type
  #lst = lapply(unique(mrds$work_type),FUN=split_cat)
  #unique(unlist(lst)) 
  #print(length(unique(mrds$work_typd)))
  #print(unique(mrds$work_type))
  
  #rcp = aggregate(dep_id~work_type, data=mrds, FUN=length)
  #sum(rcp$dep_id)
  
  #A clasification using an evolving model of geologey, muliples are seperated by
  #brackets (but only ~ 16500 sites have these clasifications of 191)
  #lst = lapply(unique(mrds$model),FUN=split_catb)
  #unique(unlist(lst)) 
  
  #print(length(unique(mrds$model)))
  #print(unique(mrds$model))
  
  #rcm = aggregate(dep_id~model, data=mrds, FUN=length)
  #sum(rcm[-1,]$dep_id)
  
  #host rock description (multiple quoted and sperated by commas)
  #lst = lapply(unique(mrds$hrock_unit),FUN=split_catbc)
  #unique(unlist(lst)) 
  
  #print(length(unique(mrds$hrock_unit)))
  #print(unique(mrds$hrock_unit))
  
  #host rock type description (sperated by commas) 152 different 
  #This might be worth looking at
  #lst = lapply(unique(mrds$hrock_type),FUN=split_cat)
  #unique(unlist(lst)) 
  
  #print(length(unique(mrds$hrock_type)))
  #print(unique(mrds$hrock_type))
  
  #ass rock description (multiple quoted and sperated by commas)
  #lst = lapply(unique(mrds$arock_unit),FUN=split_catbc)
  #unique(unlist(lst)) 
  
  #print(length(unique(mrds$arock_unit)))
  #print(unique(mrds$arock_unit))
  
  #ass rock type description (sperated by commas) 129 different 
  #maybe interesting to look at
  #lst = lapply(unique(mrds$arock_type),FUN=split_cat)
  #unique(unlist(lst)) 
  
  #print(length(unique(mrds$arock_type)))
  #print(unique(mrds$arock_type))
  
  #surroundings descriptive (multiple quoted comma seperated)
  #lst = lapply(unique(mrds$structure),FUN=split_catbc)
  #unique(unlist(lst)) 
  
  #print(length(unique(mrds$structure)))
  #print(unique(mrds$structure))
  
  #surroundings descriptive
  #print(length(unique(mrds$tectonic)))
  #print(unique(mrds$tectonic))
  
  #just a persons name, no company
  #print(length(unique(mrds$discr)))
  #print(unique(mrds$discr))
  
  #Duration: start time and end time data. Only 6% of the total data
  #test = us[!is.na(us$yr_fst_prd) & (us$yr_fst_prd > 0) & (us$yr_lst_prd > 2010 | is.na(us$yr_lst_prd)),]  
  #hist (test$yr_fst_prd)  
  #stt = aggregate( dep_id ~ state,data=test,FUN=length)  
  #year_diff = mrds$yr_lst_prd - mrds$yr_fst_prd 
  #year_diff = as.data.frame(year_diff) 
  #yeard = year_diff[!is.na(year_diff$year_diff) & year_diff$year_diff < 300,]  
  #summary(yeard)
  #hist(yeard) 
  #years = mrds[!is.na(mrds$yr_fst_prd) & (mrds$yr_fst_prd > 1830),]$yr_fst_prd 
  #summary(years)  
  #hist(years)
  
  #summary(years_there)
  #nrow(years_there[is.na(years_there$yr_fst_prd),])
  #nrow(years_there[is.na(years_there$yr_lst_prd),])
  #nrow(years_there[!is.na(years_there$yr_fst_prd) & !is.na(years_there$yr_lst_prd),])
  #nrow(years_there[!is.na(years_there$yr_lst_prd),])
  
  #cost = aggregate(dep_id~country, data=years_there[years_there$yr_fst_prd>1950,], FUN=length)
  #boxplot(yr_fst_prd ~ country, data=years_there[years_there$yr_fst_prd>1950,])
  #boxplot(yr_lst_prd ~ country, data=years_there)
  #sum(cost$dep_id)
  
  #com_there = get_sums(years_there$commod1)
  
  #cost2 = cost[cost$dep_id >100,]
  
  # question: given a commodity or ore can I get relatve location information.
  # Counts in state and/county
  
  # Look at creating relational tables for better searches of the data.
  # The binary data is getting way too big for a data table.
  
  #st = aggregate( dep_id ~ state,data=us,FUN=length)
 
  #the mineplant data
  #sort(unique(mineplant$COMMODITY))
  
 
  #length(unique(mineplant$dep_id))
  
  #hist(mineplant$dist)
  
  #nrow(mineplant[mineplant$dist>20,])
  
  #mines = mineplant[grepl("M",mineplant$PLANT_MIN, perl=TRUE),]
  #length(unique(mines$dep_id))
  #current_breakout = get_sums(mines$COMMODITY)
  #current_breakout = current_breakout[current_breakout$sum < 100,]
  #pie(current_breakout$sum, labels=current_breakout$all_stuff)
  #sum(current_breakout$sum)
  
  #aggregate(dist ~ COMMODITY, data = mineplant, FUN=max)
  
  #unique_commodity = aggregate(dep_id ~ COMMODITY, data = mineplant, FUN=unique_dif)
  
  #unique_commodity = unique_commodity[unique_commodity$dep_id == 0,]$COMMODITY
  
  #mineral_mines = mineplant[mineplant$COMMODITY %in% unique_commodity,]
  
  #mineral_mines = merge(mineral_mines,mrds,by=c("dep_id"), )
  
  #aggregate(dep_id ~ COMMODITY, data = mineral_mines, FUN=length)
  
  #length(unique(mineral_mines$SITE_NAME))
  
  #unique(mineral_mines$SITE_NAME)
  
  #copper = mineral_mines[mineral_mines$COMMODITY == "Copper",]
  
  #all_s = get_sums(mineral_mines$commod1)
  #all_s2 = get_sums(mineral_mines$commod2)
  #all_s3 = get_sums(mineral_mines$commod3)
  
  #all_s = merge(all_s, all_s2, by=c("all_stuff"), all.x=TRUE)
  
  #all_s = merge(all_s, all_s3, by=c("all_stuff"), all.x=TRUE)
  
  #ore_stuff = get_sums(mineral_mines$ore)
  
  #ore_exist = get_existance(mineral_mines$ore)
  
  #ore_exist$dep_id = mineral_mines$dep_id
  
  #ore_exist$COMMODITY = mineral_mines$COMMODITY
  
  #gangue_stuff = get_sums(mineral_mines$gangue)
  
  #model = create_model_frame(mineral_mines)
  
  #length(unique(mineral_mines$dep_id))
  
  #summary(mineral_mines)
}

data_regression_analysis = function(tables){
  
  # unpackage the data
  mrds = as.data.frame(tables[1])
  mineplant = as.data.frame(tables[2])
  test = as.data.frame(tables[3])
  
  # only use sites within three nautical miles of of an mrds site
  mineplantr = mineplant[mineplant$dist < 3,]

  # get the unique dep_id for the current mines and plants.
  current_dep = unique(mineplantr$dep_id)
  
  # sparate the data set into current and non-current
  mrdsc = mrds[(mrds$dep_id %in% current_dep), ]
  mrdsnc = mrds[!(mrds$dep_id %in% current_dep), ]
  
  # loop through the test data configuation file.
  for( index in 1:nrow(test) ){
    
    #pull out the test file parameters
    test_commodity = test[index,]$test_commodity
    test_modelcol = test[index,]$test_modelcol
    test_percent_sample = test[index,]$test_percent_sample
    test_p_value = test[index,]$test_p_value 
    test_number_of_trials = test[index,]$test_number_trials
    
    #print out as a header for the test run
    print("")
    print("test run")
    print(sprintf("Commodity being tested: %s", test_commodity))
    print(sprintf("Column being tested: %s", test_modelcol))
    print(sprintf("persent training set: %s", test_percent_sample*100))
    print(sprintf("p value sesitivity: %s", test_p_value))
    print(sprintf("number of trials: %s", test_number_of_trials))
    
    # remive all sites that have blank values for the field that is being examkned.
    model_col =  c(as.character(test_modelcol)) 
    mrdsr = mrdsnc[mrdsnc[,model_col] != "",]
    mrdsd = mrdsc[mrdsc[,model_col] != "",]

    # get the set of sites with and without the commodity
    cmodset = get_rows_exist(mrdsr,test_commodity)
    print(sprintf("number of sites with the commodity: %d",length(cmodset)))  
    ncmodset <- setdiff(c(1:nrow(mrdsr)),cmodset)
       
    # Multiple trials set for the test. This will loop through the trials 
    # It will also reloop if the regression fails. reestablishing a new 
    # randomn data set.I found that multiple trials did not show that much
    # difference in the prodiction information.
    trial_number = test_number_of_trials
    while(trial_number > 0)
    {
       # setting up the training and test sets. using 3000 to bound the amount
       # of non-comodity sites used. found little differend in using the whole set
       # and the is much faster and can run several trial if needed. also the keeps
       # the non-commodiry sites from overwhelming the confution matrx. i was going 
       # to make this configiable but 3000 appears to work well.
       percenttrain = round(length(cmodset)*test_percent_sample)
       commodity_train_samples = sample(cmodset,percenttrain)    
       non_commodity_subsample = sample(ncmodset,3000)
       percenttrainnon = round(3000*test_percent_sample)
       mon_commodity_train_samples = sample(non_commodity_subsample,percenttrainnon)
       trainset = c(commodity_train_samples ,mon_commodity_train_samples)
       testset = c(setdiff(cmodset,commodity_train_samples),setdiff(non_commodity_subsample,mon_commodity_train_samples))
       
       # created the model by breaking each value into a boolean column vector of 
       # exisence for the site within the tested field and adding an outcome
       # column of comodity existence for the site. Then running the regession 
       model = create_model_frame(mrdsr[trainset,],model_col)   
       model$outcomes = produce_binary_list(test_commodity,mrdsr[trainset,]$commod1)    
       logit = suppressWarnings(glm(outcomes ~., data = model, family = binomial))
    
       # A bit of a shorcutting here. instead of going through an elaborate algoithim
       # of determining which values beging in the regestion or not I simply based
       # it on the p-value. The more commodity sites I has the lower the p-value.
       # I grabed those values and redid the regression. I don't know how accurate 
       # the data is and in the end I am just wanting a herisic or indication of
       # how usefull the data is.
       slogit = coef(summary(logit))
       slogit = as.data.frame(slogit)
       ceofnames = row.names(slogit[slogit[,4] < test_p_value,])[-1]
       ceofnames = gsub('TRUE', '',ceofnames, perl=TRUE)
       ceofnames = gsub('\u0060', '',ceofnames, perl=TRUE)
    
       # Sometimes the initial regression comes back with no sigificand valuses.
       # the trycatch will retun null and s retry of the test run will happen
       logit = tryCatch({
          glm(outcomes ~ ., data = model[,c(ceofnames,"outcomes")], family = binomial)
       }, warning = function(w) {
         
       }, error = function(e) {
       
       }, finally = {
    
       })
    
       # If we have a cadidate model let's see the results.
       if ( !is.null(logit) )
       { 
          # print the trial number
          trial_number = trial_number - 1 
          print (sprintf( "trial number: %d",test_number_of_trials - trial_number))
         
          # Print the logit results
          print("summary of the logit model")
          print(summary(logit))
          plot(predict(logit),residuals(logit),col=c("blue","red")[1+model$outcomes],main=paste(test_commodity," ",test_modelcol))
          abline(h=0,lty=2,col="grey")
          lines(lowess(predict(logit),residuals(logit)),col="black",lwd=2)
          
          #plot(logit,which=2, main=paste(test_commodity," ",test_modelcol))
          
          logistic_prediction = prediction(logit$fitted.values, model$outcomes)
          
          # using accuacy curve to create a cutoff value.
          acc_logistic = performance(logistic_prediction, measure = "acc")
          ind = which.max( slot(acc_logistic, "y.values")[[1]] )
          max_cutoff = slot(acc_logistic, "x.values")[[1]][ind]
                  
          # pull out the positive coefficent values and order be decreasing
          # Coefficent magnitude
          slogit = coef(summary(logit))
          slogit = as.data.frame(slogit)
          slogit = slogit[-1,]
          slogit = slogit[order(-slogit[,1]),]
          mineralnames = row.names(slogit[slogit[,1]>0,])
          mineralnames = gsub('TRUE', '',mineralnames, perl=TRUE)
          mineralnames = gsub('\u0060', '',mineralnames, perl=TRUE)
          print(mineralnames)
          
          # Now set up the test model and get the prediction information. Put
          # the try catch because initially the test data may not have a value in
          # the model. Fixed this by using the training data list for boolean column
          # vectors.
          modelp = create_model_frame_list(mrdsnc[testset,],mrdsnc,model_col)
          predict_test  = tryCatch({
            predict(logit, newdata = modelp, type="response")
          }, warning = function(w) {
            
          }, error = function(e) {
            print(e)
            return(NULL)
          }, finally = {
            
          })
          
          # if successful let's get the summary of the confution matrix. 
          if(!is.null(predict_test))
          {
            test_outcomes = produce_binary_list(test_commodity,mrdsr[testset,]$commod1)     
            test_predictions = as.numeric(predict_test > max_cutoff)
            
            tryCatch({
              print("summary of the confussion matrix for the test data")
              suppressWarnings(print(confusionMatrix(test_predictions, as.numeric(test_outcomes))))
            }, warning = function(w) {
              print(w)
            }, error = function(e) {
              if (grepl("there must be at least 2 factors levels in the data", e$message) |
                  grepl("the data cannot have more levels than the reference", e$message))
              {
                 print("Data not shown: The reference or predictions are ether all zero or one. not useful to look at")
              }
              else
              {
                print(e)
              }
            }, finally = {
              
            })
            
            # let's get the prediction for the current date
            modeld = create_model_frame_list(mrdsd,mrdsnc,model_col)
            
            predict_current  = tryCatch({
              predict(logit, newdata = modeld, type="response")
            }, warning = function(w) {
              
            }, error = function(e) {
              print(e)
              return(NULL)
            }, finally = {
              
            })
            
            # let's get the summary of the confution matrix.
            if(!is.null(predict_current))
            {
               current_predictions = as.numeric(predict_current > max_cutoff)
               current_outcomes = produce_binary_list(test_commodity,mrdsd$commod1)  
               predict_current  = tryCatch({
                  print("summary of the confussion matrix for the current data")
                  suppressWarnings(print(confusionMatrix(current_predictions, as.numeric(current_outcomes))))
               }, warning = function(w) {
                  print(w)
               }, error = function(e) {
                 if (grepl("there must be at least 2 factors levels in the data",e$message) |
                     grepl("the data cannot have more levels than the reference",e$message))
                 {
                     print("Data not shown: The reference or predictions are ether all zero or one. not useful to look at")
                 }
                 else
                 {
                     print(e)
                 }
               }, finally = {
                
               })
            }  
         }    
      }   
    }    
  }    
}

if(interactive()){
  
  ##----Setup Test Logger----
  basicConfig()
  addHandler(writeToFile, file="~/testing.log", level='DEBUG')
  
  loginfo("starting program.", logger="data_logger")
  
  loginfo("loading data.", logger="data_logger") 
  tables = loading_data()
  
  loginfo("data table analysis", logger="data_logger") 
  data_table_analysis(tables)
  
  loginfo("data regression analysis", logger="data_logger") 
  pdf(paste(output_file_name,".pdf"))
  sink(paste(output_file_name,".txt"))
  data_regression_analysis(tables)
  sink()
  dev.off()

  time_stamp = format(Sys.time(),"%s")
  output_data = paste(output_file_name,time_stamp, ".txt")
  output_data_graph = paste(output_file_name,time_stamp, ".pdf")
  file.copy(paste(output_file_name,".txt"), output_data)
  file.remove(paste(output_file_name,".txt"))
  file.copy(paste(output_file_name,".pdf"), output_data_graph)
  file.remove(paste(output_file_name,".pdf"))
  
  loginfo(sprintf("Run reports are in %s and %s files.",output_data,output_data_graph), logger="data_logger")
  
  loginfo("ending program.", logger="data_logger")
}
